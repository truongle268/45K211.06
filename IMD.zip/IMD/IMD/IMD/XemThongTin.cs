﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMD
{
    public class XemThongTin
    {
        public string HoTen { get; set; }
        public string MaSV { get; set; }
        public string BienSo { get; set; }
        public string DongXe { get; set; }
        public string MauXe { get; set; }
       

        //    HoTen": "Lê Thị Trúc Ly",
        // "MaSV": "191121521118",
        //"BienSo": "43B1375     ",
        // "DongXe": "Honda Vario",
        //  "MauXe": "màu đen",
        //  "NhapMatKhau": "56789     ",
        // "NhapLaiMatKhau": "56789     "
    }
}

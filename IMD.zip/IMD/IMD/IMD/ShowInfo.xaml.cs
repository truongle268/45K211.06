﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace IMD
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShowInfo : ContentPage
    {
        HttpClient client = new HttpClient();
        string url = "http://192.168.101.229:100/api/ ";
        public ShowInfo()
        {
            InitializeComponent();
        }

       async void btnEdit_Clicked(object sender, EventArgs e)
        {
            var uri = url + "XemThongTin";
            var result = await client.GetStringAsync(uri);
            var XemThongTin = JsonConvert.DeserializeObject<List<ShowInfo>>(result);


        }

        private void btnDelete_Clicked(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMD.Models
{
    public class Constants
    {
        public static bool IsDev = true;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMD.Models
{
    public class User
    {
        public string Bsx { get; set; }
        public string Hovaten { get; set; }
        public int Msv { get; set; }
        public string Dongxe { get; set; }
        public string Mauxe { get; set; }
        public string Password { get; set; }

    }
}

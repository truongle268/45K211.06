﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMD
{
    public class Host
    {
        static public string url = "http://192.168.101.229:100/api/";
    }
}
